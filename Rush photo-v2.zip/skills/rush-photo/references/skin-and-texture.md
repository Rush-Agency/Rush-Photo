# Skin and texture

Texture is what separates a photograph from a render. Every surface in a real frame has a history: skin has weather and age, fabric has been washed, a phone case has been dropped. Write that history in.

## Contents
- Skin
- Hair
- Eyes, lips, teeth
- Hands
- Fabric and clothing
- Product surfaces
- Food and drink
- How much to use

---

## Skin

Select four to six per prompt. Match them to the subject, the light and the framing. A wide lifestyle shot does not need pore-level detail, and a tight beauty crop needs all of it.

**Surface**
- Visible pores across the nose and cheeks, finer at the temples
- Peach fuzz along the jawline and upper lip, catching the light
- Fine vellus hair on the cheeks visible in backlight
- Skin texture unretouched, the natural irregularity of real skin
- Slight sheen on the forehead and nose bridge, matte at the cheeks

**Colour and tone**
- Natural redness across the cheeks, nose and around the nostrils
- Skin tone shifting between forehead, cheeks, jaw and neck rather than one flat value
- Slight darkening around the eyes, not concealed
- Warmth at the ears and fingertips where the skin is thin
- Sun exposure showing at the forearms and the back of the neck

**Character**
- Subtle freckles, uneven in size and distribution, denser across the nose
- A small healing blemish near the chin
- Fine lines at the outer corners of the eyes that deepen with the smile
- A faint scar at the eyebrow
- Skin creasing naturally at the neck when the head turns
- Moles placed irregularly, not mirrored

**Negations that earn their place**
- Not airbrushed, not smoothed, not plastic
- No beauty filter, no skin softening
- Not waxy, not uniform

## Hair

- Baby hairs at the hairline, not smoothed flat
- Individual strands lifting away from the mass, catching the light
- Flyaways at the crown
- Natural volume variation, not helmet-like
- Visible scalp at the part
- Coils with genuine variation in size and definition
- Slightly frizzy at the ends where the hair is older
- Edges laid but not glass-flat

## Eyes, lips, teeth

**Eyes**
- Catchlight matching the light source in shape and position
- Visible iris pattern, radial fibres rather than flat colour
- Slight moisture at the lower lid
- Lower lashes present and shorter than the upper
- Faint red at the inner corner
- Eyes not perfectly symmetrical, one lid slightly lower

**Lips**
- Vertical texture lines across the lip surface
- Uneven natural colour, deeper at the centre
- Slight dryness at the edges
- The lip line soft rather than drawn
- If gloss is present, an uneven highlight, not a uniform shine

**Teeth**
- Natural white, not luminous
- Slight variation between teeth in shade and alignment
- Gum line visible and asymmetrical in the smile

## Hands

Hands are the second most common tell after text. Be explicit.

- Five fingers, correct proportion, natural relaxed curl
- Visible knuckle creases and tendon lines on the back of the hand
- Nails with a defined bed and cuticle, not painted-on shapes
- Veins faintly visible under the skin on the back of the hand
- The grip physically consistent with the weight of the object
- Fingertips slightly flattened where they press the surface

## Fabric and clothing

- Creases where the garment has been folded and stored
- Fabric weave visible at close range, cotton grain or denim twill
- Natural drape following the body, gathering at the elbow and waist
- Seam lines and stitching with real thread
- Slight pilling at the cuff
- Fabric responding to gravity and movement, not floating
- Where a logo would sit: blank, unbranded, no text

## Product surfaces

- Fingerprint smudge on the screen catching the light
- A fine scratch on the bezel
- Matte plastic showing mould texture, not perfect gloss
- The reflection on the screen showing the room, not a blank rectangle
- Packaging with a visible fold and a slight crease at the corner
- Label edges lifting very slightly
- All branding removed, blank surfaces, no text, no logos

## Food and drink

- Condensation beading on the cold glass, drips running where the beads have joined
- Steam rising and dissipating, not a solid plume
- Crumbs scattered on the board, not arranged
- Sauce pooling naturally rather than piped
- The cut edge showing real internal structure
- Bread crust with irregular blistering
- A cup half drunk, ring mark on the saucer

## How much to use

The failure mode at both ends is the same: the image looks generated.

Too little and skin renders as smooth plastic. Too much and every pore, freckle, line and blemish is rendered at maximum strength, giving an over-textured face that looks like a displacement map.

Calibrate to the crop:

| Crop | Texture cues |
|---|---|
| Beauty, tight face | 6 to 8, including pore-level detail |
| Portrait, head and shoulders | 4 to 6 |
| Half body | 3 to 4, coarser cues only |
| Full body, environmental | 2, plus hair and fabric |
| Group or wide lifestyle | 1 general cue, focus texture on fabric and setting |
