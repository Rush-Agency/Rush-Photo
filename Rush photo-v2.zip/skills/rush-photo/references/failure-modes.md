# Failure modes

Each entry is a reason an image reads as AI, and the phrasing that counters it. When a user says an image looks fake without saying why, work down this list against what they sent.

## The face

**Plastic skin.** No pores, uniform tone, every blemish gone. The most common failure.
> visible pores across the nose and cheeks, natural redness at the nostrils, skin texture unretouched, not airbrushed or smoothed

**Symmetry.** Both sides of the face identical, both eyes level, the smile even.
> features naturally asymmetrical, the left eye slightly lower, the smile lifting more on one side

**Dead eyes.** Flat iris colour, catchlight in the wrong place or absent, no moisture.
> catchlight in both eyes matching the window position, visible radial iris fibres, slight moisture along the lower lid

**Perfect teeth.** Uniform white rectangles.
> teeth natural in shade with slight variation between them, one incisor marginally forward

**Ageless.** A forty year old with no expression lines.
> fine lines at the outer eyes deepening with the smile, faint creasing across the forehead

**Hair as a mass.** Sculpted, no individual strands, no scalp.
> individual strands separating at the edges, baby hairs at the hairline, scalp visible at the part

## The hands

**Wrong count or geometry.** Six fingers, a thumb on the wrong side, fingers of equal length.
> five fingers on each hand, correct proportion, thumb positioned naturally against the grip

**Floating grip.** The hand near the object rather than holding it.
> fingers wrapping the cup with the fingertips flattening slightly against the ceramic where they press

## The light

**No direction.** Even illumination from nowhere, no shadow anywhere.
> single window camera left, bright on the near cheek and falling off toward the far side

**Inconsistent shadows.** The subject lit from the left, the props casting right.
> all shadows falling consistently to the right of their objects, matching the single light source

**Waxy highlight.** Skin highlights that look like polished wax.
> highlights on the forehead and nose bridge with the natural sheen of skin, rolling off rather than clipping

## The frame

**Dead centre.** Subject centred, symmetrical, facing the lens, both feet planted.
> shot slightly off centre and a little above eye level, caught mid-movement, looking off frame

**Nothing cropped.** Every object fully inside the frame, nothing interrupted by the edge.
> the second chair cropped by the left edge, part of the table running out of frame

**No camera.** No depth cue, everything equally sharp with no optical character.
> 85mm at f/2, sharp through the face with the background dissolved into soft tone

## The surfaces

**Garbled text.** Invented lettering on any label, sign, screen or garment. The single most obvious tell.
> all packaging blank and unbranded, no text, no logos, no lettering anywhere in the frame

**Too clean.** New objects, no wear, no dust, nothing used.
> a fine scratch on the bezel, a fingerprint smudge on the screen, the corner of the box creased

**Floating objects.** Items not making contact, shadowless where they meet a surface.
> a tight contact shadow where the base meets the counter, the object sitting with its full weight

## The whole image

**HDR flatness.** Everything at the same tonal value, shadows lifted to grey, no black point.
> real shadow depth, the darkest areas going properly black rather than lifting to grey

**Over-sharpening.** Halo edges, crunchy detail everywhere.
> natural lens sharpness, no halo at the contrast edges

**Stock composite.** Subject and background clearly from different photographs.
> subject and background sharing the same light direction, colour temperature and atmospheric haze

## When the user just says it looks wrong

Ask what specifically. If they cannot say, work top down: skin first, then hands, then light direction, then text on surfaces. Those four account for most of it.
