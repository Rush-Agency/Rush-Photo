# Camera and lighting

## Contents
- Lens choice by subject
- Aperture and what it does
- Shutter and motion
- Lighting setups
- Colour and film character

---

## Lens choice by subject

The focal length changes the geometry of a face and the sense of depth. This is a real optical effect and models reproduce it, so choosing correctly does more than adding "professional photography".

| Subject | Focal length | Why |
|---|---|---|
| Tight portrait, head and shoulders | 85mm to 135mm | Compresses features, flattering, background falls away |
| Half body portrait | 50mm to 85mm | Natural proportion, mild separation |
| Environmental portrait, person in their space | 35mm | Shows the room without distorting the face |
| Lifestyle group, table scene | 35mm | Fits several people, keeps the setting readable |
| Interior, room shot | 24mm to 28mm | Wide enough for the space, straight verticals |
| Product on white | 100mm macro | No distortion, edge to edge sharpness |
| Product detail, texture | 100mm macro | Surface detail at close range |
| Food overhead | 50mm | Flat plane, no corner stretching |
| Street, documentary | 35mm or 28mm | Close working distance, context included |

Avoid wide lenses close to a face. A 24mm portrait at arm's length enlarges the nose and narrows the ears, and while that is a real photographic effect it rarely serves commercial work.

## Aperture and what it does

Name the aperture, then say what it produces. The second half is what the model acts on.

| Aperture | Effect | Phrasing |
|---|---|---|
| f/1.4 to f/1.8 | Very shallow, one eye sharp | "focus on the near eye, the far eye already softening" |
| f/2 to f/2.8 | Shallow, subject separated | "sharp through the face, the background dissolved into soft tone" |
| f/4 | Moderate | "the subject sharp, the room behind readable but not detailed" |
| f/5.6 to f/8 | Deep, most things sharp | "everything from the front of the table to the far wall holding focus" |
| f/11 to f/16 | Very deep, landscape and architecture | "sharp from the foreground stones to the ridge line" |

For products, f/8 to f/11 keeps the whole item sharp. Shallow depth on a product hides the thing being sold.

## Shutter and motion

Only mention shutter speed when motion is in the frame. Otherwise it adds noise.

- Freezing action: 1/1000 or faster, "water droplets suspended, no blur"
- Natural hand-held: 1/125 to 1/250, "a trace of movement in the trailing hand"
- Intentional motion blur: 1/30 with a static subject, "the passing kombi streaked, the vendor sharp"
- Panning: "the runner sharp against a horizontally streaked background"

## Lighting setups

### Golden hour
Low, warm, directional. Long shadows, rim light on hair and shoulders, haze if the sun is in frame.
> Low sun about forty minutes before setting, coming from behind her right shoulder, rimming the hair and throwing a long soft shadow across the ground toward the camera

### Overcast
Soft, omnidirectional, no hard shadow. Good for skin, flat for products.
> Heavy overcast, light arriving from the whole sky, no visible shadow edge anywhere, colours slightly muted and cool

### Window light
The most useful indoor setup. Direction from the window, falloff across the frame.
> Single large window camera left, unfiltered daylight, bright on the near cheek and falling off sharply toward the far side of the face, the shadow side lifted only by the white wall behind

### Open shade
Under an eave or a tree on a sunny day. Soft light, cool cast, bright background.
> Standing in the shade of the veranda with full sun on the yard behind, soft even light on the face, the background two stops brighter

### Mixed indoor
Daylight plus practical lamps. Warm and cool in the same frame, which reads as real because studios avoid it.
> Late daylight through the doorway meeting the warm tungsten of the ceiling fitting, cool on one side of her face, warm on the other

### Hard sun
Midday, high contrast, sharp shadow edges. Difficult but honest.
> Direct overhead sun, hard shadow under the brow and nose, highlights on the forehead and cheekbones close to clipping

### Practical sources
Screens, candles, neon, headlights, phone screens. Strong colour and direction.
> Lit almost entirely by the laptop screen, cool blue on the face from below, the room behind falling into darkness

### Studio, when studio is wanted
Name the modifier and its position.
> Single large softbox at forty five degrees camera left and slightly above, white bounce card on the right lifting the shadow, seamless mid-grey backdrop

## Colour and film character

Useful when the image should feel photographed rather than rendered. Use sparingly, one cue not four.

- "slight warm cast, whites not perfectly neutral"
- "fine grain visible in the shadow areas"
- "highlights rolling off rather than clipping to pure white"
- "a little chromatic aberration at the frame edge"
- "shot on Portra 400, muted colour, warm skin"
- "very slight vignette from the lens, not added in post"

Do not stack these. One imperfection reads as a real camera, four reads as a filter.
