---
name: rush-photo
description: Write AI image prompts that produce photographs rather than renders, covering real camera and lens settings, natural light, lifestyle framing, and human skin texture including pores, peach fuzz, baby hairs, freckles and natural lip texture. Use this whenever the user asks for an image prompt, a Midjourney, Gemini, DALL-E, Flux or Nano Banana prompt, asks to edit or retouch an existing photo with AI, mentions photorealism, realistic skin, product or lifestyle photography, or says an AI image looks fake, plastic, waxy or airbrushed. Also use it when the user simply describes a scene they want generated, even if they never say the word prompt.
---

# Rush Photo

AI images read as fake for a small number of recurring reasons: skin with no texture, light with no direction, framing that no photographer would choose, and a scene with no camera behind it. This skill writes prompts that fix those four things.

The principle throughout: describe a photograph that was taken, not an image that was generated. Every clause should be something a photographer, a stylist or a subject actually did.

## Two modes, and the distinction matters

**Generation.** No source image. Building a scene from nothing. The prompt carries the full scene, camera, light and subject description.

**Edit.** A source image exists and specific things about it change. This is the more common request and the easier one to get wrong, because a prompt written in generation language will regenerate the whole frame and lose the original.

For edits, open with edit language and list only what changes:

> Edit this exact photograph. Keep the pose, expression, camera angle, framing and background unchanged. Change only the following: ...

Then, at the end, restate what is preserved. Models drift on long edit lists, and the closing constraint pulls them back. If the user has not said whether they want an edit or a generation but has attached or referenced an image, assume edit.

## Prompt structure

Write as flowing prose, one to three paragraphs. Not a bulleted specification, not a list of tags separated by commas, and never split into a version per platform. A single unified prompt should work across Midjourney, Gemini, DALL-E, Flux and Nano Banana. Where the user needs platform parameters such as aspect ratio flags, append them at the end rather than restructuring the prompt.

Deliver the prompt bare. No preamble, no "here is the prompt", no bold **Prompt** heading above it. If something needs flagging, put it after the prompt, not before.

Sequence within the prompt:

1. What the photograph is, in one sentence
2. Subject, wardrobe, styling
3. Skin and hair texture
4. Setting and props
5. Light, named by source and direction
6. Camera, lens, aperture, and what that does to the frame
7. Preservation constraints if this is an edit

## Camera settings that mean something

A prompt saying "shot on a DSLR, 4K, highly detailed" adds nothing. Those words appear on every stock listing and every render. Specific settings change the actual image because they imply real optical behaviour:

> 85mm at f/2, shallow enough that the earring is sharp and the far shoulder is not

> 35mm at f/8, everything from the counter to the back wall holding focus

> 1/1000 at ISO 400, freezing the water without a flash look

Name the aperture and say what it does. A model handles "background falling into soft blur, foreground crisp" better than "bokeh". See `references/camera-and-lighting.md` for lens choices by subject, working apertures and shutter behaviour.

## Natural lighting

Light needs a source, a direction and a quality. "Natural lighting" alone is the same empty phrase as "4K".

> Late afternoon sun through a west-facing window, falling across her left side, the shadow edge soft where it crosses her jaw

> Overcast midday, light coming from everywhere and nowhere, no hard shadow under the chin

Direction is what sells realism, because it forces consistent shadows across the face, the props and the background. Reference file covers golden hour, overcast, window light, mixed indoor, open shade and practical light sources.

## Skin texture

This is where most AI portraits fail, and where the most specific language pays off. Skin in a real photograph is not uniform. Write it that way.

The vocabulary, used selectively rather than all at once:

- Visible pores across the nose and cheeks, finer at the temples
- Peach fuzz catching the light along the jaw and upper lip
- Baby hairs at the hairline, not perfectly smoothed
- Subtle freckles, uneven in distribution
- Natural redness across the cheeks, nose and around the nostrils
- Lips with vertical texture lines and slightly uneven colour, not glossed flat
- Fine lines at the outer eye that move with the expression
- Slight shine on the forehead and nose bridge where the skin is oilier
- A small blemish or two, healing rather than staged
- Skin tone varying between the forehead, cheeks and neck rather than one flat value

Pick four to six that suit the subject and the light. Loading in all ten produces an over-described face that looks as artificial as no texture at all. Match the selection to the person: baby hairs matter on a subject with pulled-back hair, forehead shine matters under hard light.

Say what to avoid as well as what to include. "Not airbrushed, not smoothed, not plastic" does real work, because the training distribution is full of retouched skin.

`references/skin-and-texture.md` has the full vocabulary bank including hair, hands, fabric and product surfaces.

## Lifestyle framing

Lifestyle photography looks unposed because of small deliberate choices: the subject caught mid-action rather than facing the lens, something cropped by the frame edge, a slightly high or low angle rather than dead centre, a hand doing something.

> Caught mid-laugh looking off to the right, not at the camera, one hand still holding the cup

> Shot slightly from above at the table edge, the second plate cropped by the frame

Avoid the centred, symmetrical, both-feet-planted composition that generation models default to.

## Products and props

Where a brand or logo would appear, say so explicitly: blank, unbranded, no text, no logos. Models invent garbled lettering otherwise, and garbled lettering is the single most obvious tell in a commercial image.

Give products real surface behaviour: the reflection on a screen, the fingerprint smudge, the seam on a moulded case, the way fabric creases where it has been folded.

## Before delivering

Check the prompt against these:

- Is there a light source with a direction, or just "natural lighting"?
- Is there an aperture and does the prompt say what it does?
- Are there four to six texture cues, not zero and not twelve?
- Is anything branded that should be blank?
- If this is an edit, does the prompt open with edit language and close with preservation constraints?
- No em dashes anywhere in the prompt.
- Spelling and grammar corrected silently rather than flagged.
- Any factual detail the user gave, such as a product model or a colour, carried through exactly.

## Reference files

- `references/camera-and-lighting.md` — lens and aperture choices by subject, lighting setups by time and place, shutter behaviour
- `references/skin-and-texture.md` — texture vocabulary for skin, hair, hands, fabric, product surfaces, food
- `references/failure-modes.md` — what makes an image read as AI, and the counter-phrasing for each
